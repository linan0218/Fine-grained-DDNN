How to Write a New Network
--------------------------

.. toctree::
   :maxdepth: 2

   convnet
   recurrentnet
