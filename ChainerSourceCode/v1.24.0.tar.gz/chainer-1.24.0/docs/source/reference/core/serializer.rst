Serializer
----------

.. currentmodule:: chainer
.. autoclass:: AbstractSerializer
   :members:
.. autoclass:: Serializer
   :members:
.. autoclass:: Deserializer
   :members:
