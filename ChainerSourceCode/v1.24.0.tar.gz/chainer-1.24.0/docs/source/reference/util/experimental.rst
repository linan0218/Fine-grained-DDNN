Experimental feature annotation
-------------------------------
.. automodule:: chainer.utils

.. autofunction:: experimental
