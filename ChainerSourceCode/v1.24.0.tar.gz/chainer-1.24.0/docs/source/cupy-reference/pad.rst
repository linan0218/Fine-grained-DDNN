Padding
================================

.. autofunction:: cupy.pad
