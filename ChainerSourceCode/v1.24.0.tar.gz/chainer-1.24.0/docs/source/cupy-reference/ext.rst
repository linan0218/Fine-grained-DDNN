External Functions
==================

.. autofunction:: cupy.scatter_add
