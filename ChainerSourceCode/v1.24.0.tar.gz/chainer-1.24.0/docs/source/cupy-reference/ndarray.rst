Multi-Dimensional Array (ndarray)
=================================

.. autoclass:: cupy.ndarray
   :members:

.. autofunction:: cupy.asnumpy
