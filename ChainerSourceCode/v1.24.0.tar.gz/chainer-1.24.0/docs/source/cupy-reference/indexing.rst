Indexing Routines
=================

.. autofunction:: cupy.take
.. autofunction:: cupy.diagonal
.. autofunction:: cupy.ix_
.. autofunction:: cupy.fill_diagonal
.. autodata:: cupy.c_
.. autodata:: cupy.r_
