Profiling
=========

time range
----------

.. autofunction:: cupy.prof.TimeRangeDecorator
.. autofunction:: cupy.prof.time_range
