Kernel binary memoization
=========================

.. autofunction:: cupy.memoize
.. autofunction:: cupy.clear_memo
