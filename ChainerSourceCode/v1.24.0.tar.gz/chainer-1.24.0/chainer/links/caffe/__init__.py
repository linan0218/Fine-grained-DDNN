from chainer.links.caffe import caffe_function


CaffeFunction = caffe_function.CaffeFunction
