Experimental feature annotation
-------------------------------
.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.utils.experimental
