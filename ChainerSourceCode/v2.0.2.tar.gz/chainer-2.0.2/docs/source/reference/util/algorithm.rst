Common algorithms
-----------------

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.utils.WalkerAlias
