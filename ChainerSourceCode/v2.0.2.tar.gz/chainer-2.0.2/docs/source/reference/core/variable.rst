Variable and Parameter
----------------------

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.Variable
   chainer.Parameter
   chainer.variable.VariableNode
