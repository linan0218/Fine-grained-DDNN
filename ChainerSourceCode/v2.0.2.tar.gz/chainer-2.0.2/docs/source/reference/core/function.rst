Function
--------

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.Function
   chainer.force_backprop_mode
   chainer.no_backprop_mode
