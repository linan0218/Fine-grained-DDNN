Serializer
----------

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.AbstractSerializer
   chainer.Serializer
   chainer.Deserializer
