Trainer triggers
================

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.training.triggers.BestValueTrigger
   chainer.training.triggers.IntervalTrigger
   chainer.training.triggers.ManualScheduleTrigger
   chainer.training.triggers.MaxValueTrigger
   chainer.training.triggers.MinValueTrigger

